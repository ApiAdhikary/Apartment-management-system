/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package as;

/**
 *
 * @author User
 */
public class As {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          Login ln = new Login();
        ln.setVisible(true);
      
        
    }
    
}
